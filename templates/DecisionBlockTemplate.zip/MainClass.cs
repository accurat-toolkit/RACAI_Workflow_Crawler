﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Agora.Builder.Interfaces;

namespace $safeprojectname$ {
    public class MainClass:DecisionBlock {
        #region DecisionBlock Members

        bool DecisionBlock.EvaluateCondition(object data, Agora.Builder.System.BaseApplication MyApplication) {
            throw new NotImplementedException();
        }

        object DecisionBlock.GetData(object data, Agora.Builder.System.BaseApplication MyApplication) {
            throw new NotImplementedException();
        }

        #endregion
    }
}
