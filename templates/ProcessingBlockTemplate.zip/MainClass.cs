﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Agora.Builder.Interfaces;

namespace $safeprojectname$ {
    public class MainClass:ProcessingBlock {
        #region ProcessingBlock Members

        object ProcessingBlock.ProcessData(object data, Agora.Builder.System.BaseApplication MyApplication) {
            throw new NotImplementedException();
        }

        #endregion
    }
}
